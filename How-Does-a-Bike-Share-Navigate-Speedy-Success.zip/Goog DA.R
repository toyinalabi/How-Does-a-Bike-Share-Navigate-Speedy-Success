#install the packages
install.packages("tidyverse")
install.packages("lubridate")
install.packages("janitor")
install.packages("data.table")
install.packages("readr")
install.packages("psych")
install.packages("hrbrthemes")
install.packages("ggplot2")
install.packages("dplyr")

#load packages
library(tidyverse)
library(lubridate)
library(janitor)
library(data.table)
library(readr)
library(psych)
library(hrbrthemes)
library(ggplot2)
library(dplyr)


August_2022 <- read_csv("Files/Data/202208–202307_Cyclistic/202208-divvy-tripdata.csv")

September_2022 <- read_csv("Files/Data/202208–202307_Cyclistic/202209-divvy-publictripdata.csv")

October_2022 <- read_csv("Files/Data/202208–202307_Cyclistic/202210-divvy-tripdata.csv")

November_2022 <- read_csv("Files/Data/202208–202307_Cyclistic/202211-divvy-tripdata.csv")

December_2022 <- read_csv("Files/Data/202208–202307_Cyclistic/202212-divvy-tripdata.csv")

January_2023 <- read_csv("Files/Data/202208–202307_Cyclistic/202301-divvy-tripdata.csv")

February_2023 <- read_csv("Files/Data/202208–202307_Cyclistic/202302-divvy-tripdata.csv")

March_2023 <- read_csv("Files/Data/202208–202307_Cyclistic/202303-divvy-tripdata.csv")

April_2023 <- read_csv("Files/Data/202208–202307_Cyclistic/202304-divvy-tripdata.csv")

May_2023 <- read_csv("Files/Data/202208–202307_Cyclistic/202305-divvy-tripdata.csv")

June_2023 <- read_csv("Files/Data/202208–202307_Cyclistic/202306-divvy-tripdata.csv")

July_2023 <- read_csv("Files/Data/202208–202307_Cyclistic/202307-divvy-tripdata.csv")

# Total number of rows
sum(nrow(August_2022) + nrow(September_2022) + nrow(October_2022) 
    + nrow(November_2022) + nrow(December_2022) + nrow(January_2023) 
    + nrow(February_2023) + nrow(March_2023) + nrow(April_2023)
    + nrow(May_2023) + nrow(June_2023) + nrow(July_2023))

#Data Validation
colnames(August_2022)
colnames(September_2022)
colnames(October_2022)
colnames(November_2022)
colnames(December_2022)
colnames(January_2023)
colnames(February_2023)
colnames(March_2023)
colnames(April_2023)
colnames(May_2023)
colnames(June_2023)
colnames(July_2023)

# Combine Data of 12 month into for smooth workflow
trip_final <- rbind(August_2022,September_2022,October_2022,November_2022,December_2022,
                    January_2023,February_2023,March_2023,April_2023,May_2023,June_2023,July_2023)

# Save the combined files
write.csv(trip_final,file = "Files/data/trip_final.csv",row.names = FALSE)

#Final data validation
str(trip_final)
View(head(trip_final))
View(tail(trip_final))
dim(trip_final)
summary(trip_final)
names(trip_final)

#Count rows with "na" values
colSums(is.na(trip_final))

#Remove missing
clean_trip_final <- trip_final[complete.cases(trip_final), ]

#Remove duplicates
clean_trip_final <- distinct(clean_trip_final)

#Remove na
clean_trip_final <- drop_na(clean_trip_final)
clean_trip_final <- remove_missing(clean_trip_final)

#Remove data with greater start_at than end_at
clean_trip_final<- clean_trip_final %>% 
  filter(started_at < ended_at)

#Renaming column for better context
clean_trip_final <- rename(clean_trip_final, costumer_type = member_casual, bike_type = rideable_type)

#Separate date in date, day, month, year for better analysis
clean_trip_final$date <- as.Date(clean_trip_final$started_at)
clean_trip_final$week_day <- format(as.Date(clean_trip_final$date), "%A")
clean_trip_final$month <- format(as.Date(clean_trip_final$date), "%b_%y")
clean_trip_final$year <- format(clean_trip_final$date, "%Y")

#Separate column for time
clean_trip_final$time <- as.POSIXct(clean_trip_final$started_at, format = "%Y-%m-%d %H:%M:%S")
clean_trip_final$time <- format(clean_trip_final$time, format = "%H:%M")

#Add ride length column
clean_trip_final$ride_length <- difftime(clean_trip_final$ended_at, clean_trip_final$started_at, units = "mins")

#Select the data we are going to use
clean_trip_final <- clean_trip_final %>% 
  select(bike_type, costumer_type, month, year, time, started_at, week_day, ride_length)

#Remove stolen bikes
clean_trip_final <- clean_trip_final[!clean_trip_final$ride_length>1440,] 
clean_trip_final <- clean_trip_final[!clean_trip_final$ride_length<5,]

#Check Cleaned data
colSums(is.na(clean_trip_final))
View(filter(clean_trip_final, clean_trip_final$started_at > clean_trip_final$ended_at))
View(filter(clean_trip_final, clean_trip_final$ride_length>1440 | clean_trip_final < 5))

#Save the cleaned data
write.csv(clean_trip_final,file = "Files/data/clean_trip_final.csv",row.names = FALSE)


#import the cleaned data
clean_trip_final <- read_csv("clean_trip_final.csv")
str(clean_trip_final)
names(clean_trip_final)

#order the data
clean_trip_final$month <- ordered(clean_trip_final$month,levels=c("Dec_21","Jan_22","Feb_22","Mar_22", 
                                                                  "Apr_22","May_22","Jun_22","Jul_22", 
                                                                  "Aug_22","Sep_22","Oct_22","Nov_22"))

clean_trip_final$week_day <- ordered(clean_trip_final$week_day, levels = c("Sunday", "Monday", "Tuesday", 
                                                                           "Wednesday", "Thursday", 
                                                                           "Friday", "Saturday"))

#Analysis:- min, max, median, average
View(describe(clean_trip_final$ride_length, fast=TRUE))

#Total no. of customers
View(table(clean_trip_final$costumer_type))

#Total rides for each customer type in minutes
View(setNames(aggregate(ride_length ~ costumer_type, clean_trip_final, sum), c("customer_type", "total_ride_len(mins)")))

#Differences between members and casual riders in terms of length of ride
View(clean_trip_final %>% 
       group_by(costumer_type) %>% 
       summarise(min_length_mins = min(ride_length), max_length_min = max(ride_length),
                 median_length_mins = median(ride_length), mean_length_min = mean(ride_length)))

#Average ride_length for users by day_of_week and Number of total rides by day_of_week
View(clean_trip_final %>% 
       group_by(week_day) %>% 
       summarise(Avg_length = mean(ride_length),
                 number_of_ride = n()))

#Average ride_length by month
View(clean_trip_final %>% 
       group_by(month) %>% 
       summarise(Avg_length = mean(ride_length),
                 number_of_ride = n()))

#Average ride length comparison by each week day according to each customer type
View(aggregate(clean_trip_final$ride_length ~ clean_trip_final$costumer_type + 
                 clean_trip_final$week_day, FUN = mean))

#Average ride length comparison by each month according to each customer type
View(aggregate(clean_trip_final$ride_length ~ clean_trip_final$costumer_type + 
                 clean_trip_final$month, FUN = mean))

#Analyze rider length data by customer type and weekday
View(clean_trip_final %>% 
       group_by(costumer_type, week_day) %>% 
       summarise(number_of_ride = n(),
                 avgerage_duration = mean(ride_length),
                 median_duration = median(ride_length),
                 max_duration = max(ride_length),
                 min_duration = min(ride_length)))

#Analyze rider length data by customer type and month
View(clean_trip_final %>% 
       group_by(costumer_type, month) %>% 
       summarise(nummber_of_ride = n(),
                 average_duration = mean(ride_length),
                 median_duration = median(ride_length),
                 max_duration = max(ride_length),
                 min_duration = min(ride_length)))

#Save the data for data visualization
write.csv(clean_trip_final,file = "Files/data/clean_trip_final_tableau.csv",row.names = FALSE)